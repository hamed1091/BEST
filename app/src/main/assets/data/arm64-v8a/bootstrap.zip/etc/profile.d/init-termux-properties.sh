if [ ! -f /data/data/com.itsaky.androidide/files/framework/.config/termux/termux.properties ] && [ ! -e /data/data/com.itsaky.androidide/files/framework/.termux/termux.properties ]; then
mkdir -p /data/data/com.itsaky.androidide/files/framework/.termux
cp /data/data/com.itsaky.androidide/files/sysroot/share/examples/termux/termux.properties /data/data/com.itsaky.androidide/files/framework/.termux/
fi
